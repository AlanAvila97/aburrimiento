# Juego de memoria 


Juego de memoria desarrollado con javascript y HTML5 ,puedes elegir el nivel de dificultad

# Inicio
![inicio](Pantallazos/1.png)

# Parejas encontradas
![parejas](Pantallazos/2.png)

# Victoria
![victoria](Pantallazos/victoria.png)


# Derrota
![derrota](Pantallazos/derrota.png)
